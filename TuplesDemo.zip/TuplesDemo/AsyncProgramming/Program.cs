﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncProgramming
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintBulkMessages();
        }

        static void PrintBulkMessages()
        {
            System.Threading.Thread.Sleep(4000);
            for (int i = 0; i < 100000; i++)
            {
                Console.WriteLine($"Printing i: {i}");
            }
        }
    }
}
