﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassDemoApp
{
    public static class Utility
    {
        public static bool CheckStringIntegerAreEqual(object item1, object item2)
        {
            if (item1.GetType() == typeof(string) && item2.GetType() == typeof(string))
            {
                return Convert.ToString(item1) == Convert.ToString(item2);
            }
            if (item1.GetType() == typeof(int) && item2.GetType() == typeof(int))
            {
                return Convert.ToInt32(item1) == Convert.ToInt32(item2);
            }
            return false;
        }

        public static int sharedValue;
    }
}
