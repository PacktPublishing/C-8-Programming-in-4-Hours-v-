﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassDemoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Utility.CheckStringIntegerAreEqual("John", "John"));
            Utility.sharedValue = 1;
            PrintSharedIntegerValue();

            Console.WriteLine($"Shared integer value in Main method: {Utility.sharedValue}\n");
        }

        static void PrintSharedIntegerValue()
        {
            Utility.sharedValue++;
            Console.WriteLine($"\nShared integer value in (PrintSharedIntegerValue): {Utility.sharedValue}\n");
        }
    }
}
