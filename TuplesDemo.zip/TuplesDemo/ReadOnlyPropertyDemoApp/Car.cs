﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadOnlyPropertyDemoApp
{
    public enum Transmission
    {
        Automatic,
        Manual
    }
    public class Car
    {
        private readonly string _make;
        public string Make { get { return _make; } }

        public Car(string make)
        {
            this._make = make;
        }

        protected Transmission _carTransmission;

    }
}
