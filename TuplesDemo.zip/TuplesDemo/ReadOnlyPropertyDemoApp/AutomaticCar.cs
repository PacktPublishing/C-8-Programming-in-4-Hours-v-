﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadOnlyPropertyDemoApp
{
    public class AutomaticCar: Car
    {
        public AutomaticCar(string make): base(make)
        {
            _carTransmission = Transmission.Automatic;
        }

        public Transmission CarTransmission
        {
            get {
                return _carTransmission;
            }
            
        }
    }
}
