﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadOnlyPropertyDemoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Readonly
            //Readonly vs Constants
            //Protected Access Modifiers
            //Internal - within current assembly/project
            //Protected Internal
        }
    }
}
