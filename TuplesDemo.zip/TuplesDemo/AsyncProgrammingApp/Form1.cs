﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncProgrammingApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }


        void PrintBulkMessages()
        {
            Thread.Sleep(4000);
            for (int i = 0; i < 10; i++)
            {
                label1.Text = $"Printing i: {i}";
                System.Threading.Thread.Sleep(500);
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            //Thread t = new Thread(PrintBulkMessages);
            //t.Start();

            label1.Text = "Thread has been started";
            //PrintBulkMessages();

            Task t = new Task(PrintBulkMessages);
            t.Start();

            await t;
            //int result = await AsyncMethod();

            label1.Text = "Thread has been stopped";
        }

        async Task<int> AsyncMethod()
        {
            await Task.Delay(4000);
            label1.Text = "Value changed";
            await Task.Delay(4000);
            return 1;
        }
    }
}
