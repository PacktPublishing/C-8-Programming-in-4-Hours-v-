﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuplesDemoApp
{
    class Program
    {
        //Passing Multiple values to a method, and returning set of values from a method.
        // Holding a record temporaly without a class.
        // No ref or out key word

        static void Main(string[] args)
        {
            Tuple<int, string, string, bool, string, string, string> data = new Tuple<int, string, string, bool, string, string, string>(101, "John Smith", "Charlotte, NC", true, "South Park", "Spectrum", "Test");

            Console.WriteLine($"{data.Item1}, {data.Item2}, {data.Item3}");

            var person = Tuple.Create(1, "Steve", "London");

            Console.WriteLine($"{ person.Item1}, { person.Item2}, { person.Item3}");

            var personProcessed = PrintPersonDetail(Tuple.Create(101, "John", "New York City"));
            Console.WriteLine($"{personProcessed.Item2} has been processed: {personProcessed.Item4}");
        }

        static Tuple<int, string, string, string> PrintPersonDetail(Tuple<int, string, string> person)
        {
            Console.WriteLine("\nPrintPersonDetail\n");
            Console.WriteLine($"{person.Item1}, {person.Item2}, {person.Item3}\n");
            return Tuple.Create(person.Item1, person.Item2, person.Item3, "Person processed");
        }
    }
}
